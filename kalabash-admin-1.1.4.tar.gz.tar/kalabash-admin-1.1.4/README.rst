####################################
`Kalabash <https://monakmail.com/>`_
####################################

********
Kalabash
********


*************
External code
*************

External libraries provided with Kalabash:

* `jQuery version 1.9.1 <http://www.jquery.org/>`_
* `jQuery-UI 1.10+ <http://jqueryui.com/>`_
* `Bootstrap version 3.3.7 <http://getbootstrap.com/>`_
* `Bootstrap datetimepicker <http://eonasdan.github.io/bootstrap-datetimepicker/>`_
