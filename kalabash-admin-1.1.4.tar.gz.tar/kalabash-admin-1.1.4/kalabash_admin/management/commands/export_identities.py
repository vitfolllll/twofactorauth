import sys
import csv
from optparse import make_option

from django.core.management.base import BaseCommand

from kalabash.core import load_core_settings
from kalabash.core.models import User
from kalabash.core.extensions import exts_pool
from kalabash.core.management.commands import CloseConnectionMixin
from ...models import Alias


class Command(BaseCommand, CloseConnectionMixin):
    help = 'Export identities (mailbox and aliases) to a csv'

    option_list = BaseCommand.option_list + (
        make_option(
            '--sepchar', action='store_true', dest='sepchar', default=';'
        ),
    )

    def handle(self, *args, **kwargs):
        exts_pool.load_all()
        load_core_settings()

        csvwriter = csv.writer(sys.stdout, delimiter=kwargs['sepchar'])
        for u in User.objects.all():
            u.to_csv(csvwriter)

        for a in Alias.objects.prefetch_related('mboxes', 'aliases'):
            a.to_csv(csvwriter)
