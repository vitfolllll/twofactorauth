default_app_config = "kalabash_admin.apps.AdminConfig"
